﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static TH05_Natalie_Grace_Widjaja_Kuswanto___Sem_2__.Main;

namespace TH05_Natalie_Grace_Widjaja_Kuswanto___Sem_2__
{
    public partial class Main : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();
        int editanbaru = 0;
        int idcategory; //counter categoryid

        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        { 
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C3");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");
            dgv_1.DataSource = dtProdukSimpan;
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
            dgv_2.DataSource = dtCategory;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_category.Items.Add(dtCategory.Rows[i][1].ToString());
                cb_filter.Items.Add(dtCategory.Rows[i][1].ToString());
            }
            dgv_1.ClearSelection();
            dgv_2.ClearSelection();
        }

        private void btn_addproduct_Click(object sender, EventArgs e)
        {
            int noid = 0;
            string hurufid = "";
            string idnya = ""; // hasil akhir 

            if (tb_nama.Text == "" || cb_category.Text == "" || tb_harga.Text == "" || tb_stock.Text == "")
            {
                MessageBox.Show("Isi yang lengkap");
            }
            else
            {
                hurufid = tb_nama.Text.ToString().Substring(0, 1).ToUpper();

                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    string idskrg = dtProdukSimpan.Rows[i][0].ToString();
                    if (idskrg.Substring(0, 1) == hurufid)
                    {
                        int nomernya = Convert.ToInt32(idskrg.Substring(1));
                        if (nomernya > noid)
                        {
                            noid = nomernya;
                        }
                    }
                }
                noid++;

                if (noid < 10)
                {
                    idnya = $"{hurufid}00{noid}";

                }
                else if (noid < 100)
                {
                    idnya = $"{hurufid}0{noid}";
                }
                else if (noid < 1000)
                {
                    idnya = $"{hurufid}{noid}";
                }

                string categoryid = "";
                
                for (int i = 0; i < dgv_2.Rows.Count; i++)
                {
                    if (cb_category.Text == dtCategory.Rows[i][1].ToString())
                    {
                        categoryid = dtCategory.Rows[i][0].ToString();
                        break;
                    }
                }
                dtProdukSimpan.Rows.Add(idnya, tb_nama.Text, tb_harga.Text, tb_stock.Text, categoryid);
                dgv_1.DataSource = dtProdukSimpan;
            }
        }

        private void btn_editproduct_Click(object sender, EventArgs e)
        {
            if (tb_nama.Text == "" || cb_category.Text == "" || tb_harga.Text == "" || tb_stock.Text == "")
            {
                MessageBox.Show("Pilih produk yang mau diedit");
            }

            else if (tb_stock.Text != "0")
            {
                dtProdukSimpan.Rows[editanbaru][1] = tb_nama.Text;
                dtProdukSimpan.Rows[editanbaru][2] = tb_harga.Text;
                dtProdukSimpan.Rows[editanbaru][3] = tb_stock.Text;
                string category = "";
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString().Substring(0, 1) == cb_category.Text)
                    {
                        category = dtCategory.Rows[i][0].ToString();
                    }
                }
                dtProdukSimpan.Rows[editanbaru][4] = category;
                for (int i = 0; i < dgv_2.Rows.Count; i++)
                {
                    if (cb_category.Text == dtCategory.Rows[i][1].ToString())
                    {
                        dgv_1.Rows[dgv_1.CurrentRow.Index].Cells[4].Value = dtCategory.Rows[i][0].ToString();
                        break;
                    }
                }
            }
            else if (tb_stock.Text == "0")
            {
                DataGridViewRow currentrow = dgv_1.CurrentRow;
                dgv_1.Rows.Remove(currentrow);
                tb_nama.Clear();
                cb_category.Text = "";
                tb_harga.Clear();
                tb_stock.Clear();
            }
        }

        private void dgv_1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow tampilan = dgv_1.CurrentRow;
            tb_nama.Text = tampilan.Cells[1].Value.ToString();
            tb_harga.Text = tampilan.Cells[2].Value.ToString();
            tb_stock.Text = tampilan.Cells[3].Value.ToString();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (tampilan.Cells[4].Value.ToString().Contains(dtCategory.Rows[i][0].ToString()))
                {
                    cb_category.Text = dtCategory.Rows[i][1].ToString();
                }
            }
            editanbaru = tampilan.Index;
        }

        private void btn_removeproduct_Click(object sender, EventArgs e)
        {
            DataGridViewRow view = dgv_1.CurrentRow;
            if(tb_nama.Text == "")
            {
                MessageBox.Show("Pilih produk yang mau diremove");
            }
            else
            {
                if (cb_filter.Text != "")
                {
                    DataGridViewRow currentrow = dgv_1.CurrentRow;
                    int indexcurrentrow = dgv_1.CurrentRow.Index;

                    dgv_1.DataSource = dtProdukSimpan;

                    for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                    {
                        if (dtProdukSimpan.Rows[i][0].ToString() == dtProdukTampil.Rows[indexcurrentrow][0].ToString())
                        {
                            dtProdukSimpan.Rows.RemoveAt(i);
                        }
                    }
                    cb_filter.Text = "";
                }
                else
                {
                    dgv_1.Rows.Remove(view);
                }
            }
            tb_nama.Clear();
            cb_category.Text = "";
            tb_harga.Clear();
            tb_stock.Clear();
        }

        private void btn_addcategory_Click(object sender, EventArgs e)
        {
            bool jalan = true;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][1].ToString() == tb_namacategory.Text)
                {
                    jalan = false;
                }
            }
            if (tb_namacategory.Text == "")
            {
                MessageBox.Show("Masukkan nama category terlebih dahulu");
            }
            else if (jalan == false)
            {
                MessageBox.Show("Nama category sudah ada");
            }
            else
            {
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    idcategory = Convert.ToInt32(dtCategory.Rows[i][0].ToString().Substring(1)); // ambil indeks habisnya C yaitu 1 seterusnya
                }
                idcategory++;
                dtCategory.Rows.Add("C" + idcategory, tb_namacategory.Text);
                
                DataGridViewRow tampilan = dgv_1.CurrentRow;
                cb_category.Items.Clear();
                cb_filter.Items.Clear();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    cb_category.Items.Add(dtCategory.Rows[i][1].ToString());
                    cb_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                    for (int j = 0; j < dgv_2.Rows.Count; j++)
                    {
                        if (cb_category.Text == dtCategory.Rows[i][1].ToString())
                        {
                            dtProdukSimpan.Rows.RemoveAt(i);
                            break;
                        }
                    }
                }             
            }
        }

        private void dgv_2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow tampilan = dgv_2.CurrentRow;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (tampilan.Cells[1].Value.ToString().Contains(dtCategory.Rows[i][1].ToString()))
                {
                    tb_namacategory.Text = dtCategory.Rows[i][1].ToString();
                }
            }
        }

        private void btn_removecategory_Click(object sender, EventArgs e)
        {
            DataGridViewRow view = dgv_2.CurrentRow;
            int count = 0;
            int totalbaris = dtProdukSimpan.Rows.Count;
            if (tb_namacategory.Text== "")
            {
                MessageBox.Show("Pilih category yang mau diremove");
            }
            else
            {
                for (int i = 0; i < totalbaris; i++)
                {
                    if (count == 0)
                    {
                        if (dtProdukSimpan.Rows[i][4].ToString().Contains(view.Cells[0].Value.ToString()))
                        {
                            dtProdukSimpan.Rows.RemoveAt(i);
                            count++;
                        }

                    }
                    else if (count > 0)
                    {
                        if (dtProdukSimpan.Rows[i - count][4].ToString().Contains(view.Cells[0].Value.ToString()))
                        {
                            dtProdukSimpan.Rows.RemoveAt(i - count);
                            count++;
                        }
                    }
                }
                if (dgv_2.Rows.Count != 0)
                {
                    dgv_2.Rows.Remove(view);
                }
                tb_namacategory.Clear();
                cb_filter.Items.Clear();
                cb_category.Items.Clear();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    cb_category.Items.Add(dtCategory.Rows[i][1].ToString());
                    cb_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                }
                dgv_1.DataSource = dtProdukSimpan;
            }
            
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = false;
            dgv_1.DataSource = dtProdukSimpan;
            cb_filter.Text = "";
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = true;

        }
        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filter = "";
            dtProdukTampil = new DataTable();
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");
            dgv_1.DataSource = dtProdukTampil;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][1].ToString() == cb_filter.Text)
                {
                    filter = dtCategory.Rows[i][0].ToString();
                }
            }
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i][4].ToString().Contains(filter))
                {
                    dtProdukTampil.Rows.Add(dtProdukSimpan.Rows[i][0].ToString(), dtProdukSimpan.Rows[i][1].ToString(), dtProdukSimpan.Rows[i][2].ToString(), dtProdukSimpan.Rows[i][3].ToString(), dtProdukSimpan.Rows[i][4].ToString());
                }
            }
        }

        private void tb_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void tb_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}