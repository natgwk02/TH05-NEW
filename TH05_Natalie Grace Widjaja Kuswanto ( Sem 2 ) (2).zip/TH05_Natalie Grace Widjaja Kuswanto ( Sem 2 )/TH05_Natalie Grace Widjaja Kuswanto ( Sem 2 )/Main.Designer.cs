﻿namespace TH05_Natalie_Grace_Widjaja_Kuswanto___Sem_2__
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.lb_product = new System.Windows.Forms.Label();
            this.lb_category = new System.Windows.Forms.Label();
            this.lb_details = new System.Windows.Forms.Label();
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            this.dgv_2 = new System.Windows.Forms.DataGridView();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_categoryy = new System.Windows.Forms.Label();
            this.lb_harga = new System.Windows.Forms.Label();
            this.lb_stock = new System.Windows.Forms.Label();
            this.lb_namaa = new System.Windows.Forms.Label();
            this.tb_namacategory = new System.Windows.Forms.TextBox();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.btn_editproduct = new System.Windows.Forms.Button();
            this.btn_addproduct = new System.Windows.Forms.Button();
            this.btn_removecategory = new System.Windows.Forms.Button();
            this.btn_addcategory = new System.Windows.Forms.Button();
            this.btn_removeproduct = new System.Windows.Forms.Button();
            this.pb_1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_product
            // 
            this.lb_product.AutoSize = true;
            this.lb_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_product.Location = new System.Drawing.Point(19, 13);
            this.lb_product.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_product.Name = "lb_product";
            this.lb_product.Size = new System.Drawing.Size(82, 24);
            this.lb_product.TabIndex = 0;
            this.lb_product.Text = "Product";
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_category.Location = new System.Drawing.Point(445, 10);
            this.lb_category.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(93, 24);
            this.lb_category.TabIndex = 1;
            this.lb_category.Text = "Category";
            // 
            // lb_details
            // 
            this.lb_details.AutoSize = true;
            this.lb_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_details.Location = new System.Drawing.Point(29, 228);
            this.lb_details.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_details.Name = "lb_details";
            this.lb_details.Size = new System.Drawing.Size(72, 24);
            this.lb_details.TabIndex = 2;
            this.lb_details.Text = "Details";
            // 
            // dgv_1
            // 
            this.dgv_1.AllowUserToAddRows = false;
            this.dgv_1.AllowUserToDeleteRows = false;
            this.dgv_1.AllowUserToResizeColumns = false;
            this.dgv_1.AllowUserToResizeRows = false;
            this.dgv_1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_1.Location = new System.Drawing.Point(23, 41);
            this.dgv_1.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.RowHeadersVisible = false;
            this.dgv_1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_1.Size = new System.Drawing.Size(393, 185);
            this.dgv_1.TabIndex = 3;
            this.dgv_1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_1_CellClick);
            // 
            // dgv_2
            // 
            this.dgv_2.AllowUserToAddRows = false;
            this.dgv_2.AllowUserToDeleteRows = false;
            this.dgv_2.AllowUserToResizeColumns = false;
            this.dgv_2.AllowUserToResizeRows = false;
            this.dgv_2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_2.Location = new System.Drawing.Point(449, 41);
            this.dgv_2.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_2.Name = "dgv_2";
            this.dgv_2.RowHeadersVisible = false;
            this.dgv_2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_2.Size = new System.Drawing.Size(208, 168);
            this.dgv_2.TabIndex = 4;
            this.dgv_2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_2_CellClick);
            // 
            // btn_all
            // 
            this.btn_all.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_all.Location = new System.Drawing.Point(123, 12);
            this.btn_all.Margin = new System.Windows.Forms.Padding(2);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(54, 25);
            this.btn_all.TabIndex = 5;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filter.Location = new System.Drawing.Point(181, 12);
            this.btn_filter.Margin = new System.Windows.Forms.Padding(2);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(51, 25);
            this.btn_filter.TabIndex = 6;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.Enabled = false;
            this.cb_filter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_filter.ForeColor = System.Drawing.Color.Black;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(236, 13);
            this.cb_filter.Margin = new System.Windows.Forms.Padding(2);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(89, 24);
            this.cb_filter.TabIndex = 7;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Location = new System.Drawing.Point(42, 252);
            this.lb_nama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(47, 16);
            this.lb_nama.TabIndex = 8;
            this.lb_nama.Text = "Nama:";
            // 
            // lb_categoryy
            // 
            this.lb_categoryy.AutoSize = true;
            this.lb_categoryy.Location = new System.Drawing.Point(24, 277);
            this.lb_categoryy.Name = "lb_categoryy";
            this.lb_categoryy.Size = new System.Drawing.Size(65, 16);
            this.lb_categoryy.TabIndex = 9;
            this.lb_categoryy.Text = "Category:";
            // 
            // lb_harga
            // 
            this.lb_harga.AutoSize = true;
            this.lb_harga.Location = new System.Drawing.Point(41, 305);
            this.lb_harga.Name = "lb_harga";
            this.lb_harga.Size = new System.Drawing.Size(48, 16);
            this.lb_harga.TabIndex = 10;
            this.lb_harga.Text = "Harga:";
            // 
            // lb_stock
            // 
            this.lb_stock.AutoSize = true;
            this.lb_stock.Location = new System.Drawing.Point(45, 331);
            this.lb_stock.Name = "lb_stock";
            this.lb_stock.Size = new System.Drawing.Size(44, 16);
            this.lb_stock.TabIndex = 11;
            this.lb_stock.Text = "Stock:";
            // 
            // lb_namaa
            // 
            this.lb_namaa.AutoSize = true;
            this.lb_namaa.Location = new System.Drawing.Point(442, 222);
            this.lb_namaa.Name = "lb_namaa";
            this.lb_namaa.Size = new System.Drawing.Size(47, 16);
            this.lb_namaa.TabIndex = 12;
            this.lb_namaa.Text = "Nama:";
            // 
            // tb_namacategory
            // 
            this.tb_namacategory.Location = new System.Drawing.Point(495, 222);
            this.tb_namacategory.Name = "tb_namacategory";
            this.tb_namacategory.Size = new System.Drawing.Size(143, 22);
            this.tb_namacategory.TabIndex = 13;
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(94, 252);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(275, 22);
            this.tb_nama.TabIndex = 14;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(94, 308);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(103, 22);
            this.tb_harga.TabIndex = 15;
            this.tb_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_harga_KeyPress);
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(94, 336);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(103, 22);
            this.tb_stock.TabIndex = 16;
            this.tb_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stock_KeyPress);
            // 
            // cb_category
            // 
            this.cb_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(94, 279);
            this.cb_category.Margin = new System.Windows.Forms.Padding(2);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(89, 24);
            this.cb_category.TabIndex = 17;
            // 
            // btn_editproduct
            // 
            this.btn_editproduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_editproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_editproduct.Location = new System.Drawing.Point(278, 296);
            this.btn_editproduct.Margin = new System.Windows.Forms.Padding(2);
            this.btn_editproduct.Name = "btn_editproduct";
            this.btn_editproduct.Size = new System.Drawing.Size(62, 47);
            this.btn_editproduct.TabIndex = 19;
            this.btn_editproduct.Text = "Edit Product";
            this.btn_editproduct.UseVisualStyleBackColor = false;
            this.btn_editproduct.Click += new System.EventHandler(this.btn_editproduct_Click);
            // 
            // btn_addproduct
            // 
            this.btn_addproduct.BackColor = System.Drawing.Color.Lime;
            this.btn_addproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addproduct.Location = new System.Drawing.Point(213, 296);
            this.btn_addproduct.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addproduct.Name = "btn_addproduct";
            this.btn_addproduct.Size = new System.Drawing.Size(61, 47);
            this.btn_addproduct.TabIndex = 18;
            this.btn_addproduct.Text = "Add Product";
            this.btn_addproduct.UseVisualStyleBackColor = false;
            this.btn_addproduct.Click += new System.EventHandler(this.btn_addproduct_Click);
            // 
            // btn_removecategory
            // 
            this.btn_removecategory.BackColor = System.Drawing.Color.Red;
            this.btn_removecategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_removecategory.Location = new System.Drawing.Point(555, 249);
            this.btn_removecategory.Margin = new System.Windows.Forms.Padding(2);
            this.btn_removecategory.Name = "btn_removecategory";
            this.btn_removecategory.Size = new System.Drawing.Size(64, 44);
            this.btn_removecategory.TabIndex = 21;
            this.btn_removecategory.Text = "Remove Category";
            this.btn_removecategory.UseVisualStyleBackColor = false;
            this.btn_removecategory.Click += new System.EventHandler(this.btn_removecategory_Click);
            // 
            // btn_addcategory
            // 
            this.btn_addcategory.BackColor = System.Drawing.Color.Lime;
            this.btn_addcategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addcategory.Location = new System.Drawing.Point(489, 249);
            this.btn_addcategory.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addcategory.Name = "btn_addcategory";
            this.btn_addcategory.Size = new System.Drawing.Size(62, 44);
            this.btn_addcategory.TabIndex = 20;
            this.btn_addcategory.Text = "Add Category";
            this.btn_addcategory.UseVisualStyleBackColor = false;
            this.btn_addcategory.Click += new System.EventHandler(this.btn_addcategory_Click);
            // 
            // btn_removeproduct
            // 
            this.btn_removeproduct.BackColor = System.Drawing.Color.Red;
            this.btn_removeproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_removeproduct.Location = new System.Drawing.Point(344, 296);
            this.btn_removeproduct.Margin = new System.Windows.Forms.Padding(2);
            this.btn_removeproduct.Name = "btn_removeproduct";
            this.btn_removeproduct.Size = new System.Drawing.Size(57, 47);
            this.btn_removeproduct.TabIndex = 23;
            this.btn_removeproduct.Text = "Remove Product";
            this.btn_removeproduct.UseVisualStyleBackColor = false;
            this.btn_removeproduct.Click += new System.EventHandler(this.btn_removeproduct_Click);
            // 
            // pb_1
            // 
            this.pb_1.ErrorImage = null;
            this.pb_1.Image = ((System.Drawing.Image)(resources.GetObject("pb_1.Image")));
            this.pb_1.InitialImage = null;
            this.pb_1.Location = new System.Drawing.Point(567, 298);
            this.pb_1.Name = "pb_1";
            this.pb_1.Size = new System.Drawing.Size(71, 75);
            this.pb_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_1.TabIndex = 24;
            this.pb_1.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(669, 379);
            this.Controls.Add(this.pb_1);
            this.Controls.Add(this.btn_removeproduct);
            this.Controls.Add(this.btn_removecategory);
            this.Controls.Add(this.btn_addcategory);
            this.Controls.Add(this.btn_editproduct);
            this.Controls.Add(this.btn_addproduct);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.tb_stock);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.tb_namacategory);
            this.Controls.Add(this.lb_namaa);
            this.Controls.Add(this.lb_stock);
            this.Controls.Add(this.lb_harga);
            this.Controls.Add(this.lb_categoryy);
            this.Controls.Add(this.lb_nama);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.dgv_2);
            this.Controls.Add(this.dgv_1);
            this.Controls.Add(this.lb_details);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.lb_product);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Main";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_product;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Label lb_details;
        private System.Windows.Forms.DataGridView dgv_1;
        private System.Windows.Forms.DataGridView dgv_2;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_categoryy;
        private System.Windows.Forms.Label lb_harga;
        private System.Windows.Forms.Label lb_stock;
        private System.Windows.Forms.Label lb_namaa;
        private System.Windows.Forms.TextBox tb_namacategory;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.Button btn_editproduct;
        private System.Windows.Forms.Button btn_addproduct;
        private System.Windows.Forms.Button btn_removecategory;
        private System.Windows.Forms.Button btn_addcategory;
        private System.Windows.Forms.Button btn_removeproduct;
        private System.Windows.Forms.PictureBox pb_1;
    }
}

