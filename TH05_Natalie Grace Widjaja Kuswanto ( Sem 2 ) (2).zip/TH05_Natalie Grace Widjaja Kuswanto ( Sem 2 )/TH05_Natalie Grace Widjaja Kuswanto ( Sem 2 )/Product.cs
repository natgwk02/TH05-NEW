﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH05_Natalie_Grace_Widjaja_Kuswanto___Sem_2__
{
    internal class Product
    {
    }
}
